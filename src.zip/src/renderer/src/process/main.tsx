import React from 'react'
import ReactDOM from 'react-dom/client'
import { ProcessApp } from './ProcessApp'
import '../styles.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ProcessApp />
  </React.StrictMode>
)

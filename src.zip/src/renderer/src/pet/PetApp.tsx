import { useCallback, useState } from 'react'

export function PetApp(): JSX.Element {
  const [dragOver, setDragOver] = useState(false)
  const [hint, setHint] = useState<string | null>(null)
  const [clickThrough, setClickThrough] = useState(false)
  const [imgOk, setImgOk] = useState(true)

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragOver(true)
  }, [])

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
  }, [])

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragOver(false)
    setHint(null)

    const files = Array.from(e.dataTransfer?.files ?? [])
    if (files.length === 0) {
      setHint('未检测到文件，请从资源管理器拖入。')
      return
    }

    const paths = files.map((f) => window.softcreate.getPathForFile(f))

    try {
      const task = await window.softcreate.analyzeDrop(paths)
      await window.softcreate.openTask(task)
    } catch (err) {
      setHint(err instanceof Error ? err.message : String(err))
    }
  }, [])

  const toggleThrough = async () => {
    const next = !clickThrough
    setClickThrough(next)
    await window.softcreate.setPetIgnoreMouse(next)
  }

  return (
    <div className="pet-root">
      <div
        className={`pet-drop ${dragOver ? 'dragover' : ''}`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={handleDrop}
      >
        {imgOk ? (
          <img
            className="pet-mascot"
            src="/mascot.png"
            alt=""
            onError={() => setImgOk(false)}
          />
        ) : (
          <div
            className="pet-mascot"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 96,
              opacity: 0.9
            }}
            aria-hidden
          >
            🎧
          </div>
        )}
        <div className="pet-hint">
          将音乐文件或文件夹拖到立绘区域
          <br />
          支持批量文件 · 可将立绘图放到 <code>public/mascot.png</code>
        </div>
      </div>
      {hint && (
        <div className="pet-hint" style={{ color: '#fecaca' }}>
          {hint}
        </div>
      )}
      <div className="pet-tools">
        <label>
          <input type="checkbox" checked={clickThrough} onChange={toggleThrough} />
          点击穿透（开启后拖放可能不稳定，按需关闭）
        </label>
      </div>
    </div>
  )
}

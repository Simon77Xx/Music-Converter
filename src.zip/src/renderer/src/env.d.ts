import type { AudioOutputFormat, DropTask } from '../../shared/types'

export {}

declare global {
  interface Window {
    softcreate: {
      getPathForFile: (file: File) => string
      analyzeDrop: (paths: string[]) => Promise<DropTask>
      openTask: (task: DropTask) => Promise<string>
      getTask: (taskId: string) => Promise<DropTask | null>
      getOutputDir: () => Promise<string>
      zipFolder: (folderPath: string) => Promise<{ outputPath: string }>
      transcode: (payload: {
        paths: string[]
        outputFormat: AudioOutputFormat
        mode: 'convert' | 'compress'
        bitrateKbps?: number
        compressProfile?: 'lossy' | 'lossless'
        flacCompressionLevel?: number
      }) => Promise<{ outputPaths: string[]; outputDir: string }>
      onJobProgress: (cb: (ratio: number) => void) => () => void
      openPath: (p: string) => Promise<void>
      showItemInFolder: (p: string) => Promise<void>
      closeProcessWindow: () => Promise<void>
      setPetIgnoreMouse: (ignore: boolean) => Promise<void>
    }
  }
}

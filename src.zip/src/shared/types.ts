export type DropKind = 'folder' | 'audio' | 'batch-audio' | 'unsupported'

export interface DropTask {
  kind: DropKind
  paths: string[]
  label: string
  proprietary?: boolean
}

export type AudioOutputFormat =
  | 'mp3'
  | 'm4a'
  | 'aac'
  | 'wav'
  | 'flac'
  | 'ogg'
  | 'opus'
  | 'wma'

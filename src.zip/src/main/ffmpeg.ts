import { spawn } from 'node:child_process'
import { basename, extname, join } from 'node:path'
import ffmpegPath from 'ffmpeg-static'
import type { AudioOutputFormat } from '../shared/types'

export type { AudioOutputFormat }

export interface TranscodeOptions {
  inputPath: string
  outputDir: string
  outputFormat: AudioOutputFormat
  /** 有损压缩目标码率 (kbps)，仅对 mp3/aac/m4a/ogg 等有意义 */
  audioBitrateKbps?: number
  /** FLAC 编码压缩等级 0–12，仅对 flac 输出有意义（无损体积优化） */
  flacCompressionLevel?: number
}

function buildOutputPath(inputPath: string, outputDir: string, format: AudioOutputFormat): string {
  const base = basename(inputPath, extname(inputPath))
  return join(outputDir, `${base}.${format}`)
}

function buildFfmpegArgs(opts: TranscodeOptions): string[] {
  const out = buildOutputPath(opts.inputPath, opts.outputDir, opts.outputFormat)
  const args = ['-y', '-i', opts.inputPath]

  switch (opts.outputFormat) {
    case 'mp3':
      args.push('-c:a', 'libmp3lame')
      if (opts.audioBitrateKbps) {
        args.push('-b:a', `${opts.audioBitrateKbps}k`)
      } else {
        args.push('-q:a', '2')
      }
      break
    case 'aac':
    case 'm4a':
      args.push('-c:a', 'aac')
      if (opts.audioBitrateKbps) {
        args.push('-b:a', `${opts.audioBitrateKbps}k`)
      } else {
        args.push('-b:a', '192k')
      }
      break
    case 'wav':
      args.push('-c:a', 'pcm_s16le')
      break
    case 'flac':
      args.push('-c:a', 'flac')
      if (opts.flacCompressionLevel !== undefined) {
        const lv = Math.min(12, Math.max(0, Math.round(opts.flacCompressionLevel)))
        args.push('-compression_level', String(lv))
      }
      break
    case 'ogg':
      args.push('-c:a', 'libvorbis')
      if (opts.audioBitrateKbps) {
        args.push('-b:a', `${opts.audioBitrateKbps}k`)
      }
      break
    case 'opus':
      args.push('-c:a', 'libopus')
      if (opts.audioBitrateKbps) {
        args.push('-b:a', `${opts.audioBitrateKbps}k`)
      } else {
        args.push('-b:a', '128k')
      }
      break
    case 'wma':
      args.push('-c:a', 'wmav2', '-f', 'asf')
      if (opts.audioBitrateKbps) {
        args.push('-b:a', `${opts.audioBitrateKbps}k`)
      } else {
        args.push('-b:a', '128k')
      }
      break
    default:
      args.push('-c:a', 'copy')
  }

  args.push(out)
  return args
}

/** 从 stderr 解析进度：需要事先用 -progress pipe:1 或解析 time= */
export function runFfmpeg(
  opts: TranscodeOptions,
  onProgress?: (ratio: number) => void
): Promise<{ outputPath: string }> {
  const ff = ffmpegPath
  if (!ff) {
    return Promise.reject(new Error('未找到 ffmpeg 可执行文件（ffmpeg-static）'))
  }

  const outputPath = buildOutputPath(opts.inputPath, opts.outputDir, opts.outputFormat)
  const args = buildFfmpegArgs(opts)

  return new Promise((resolve, reject) => {
    const proc = spawn(ff, args, { windowsHide: true })
    let durationSec = 0
    let stderr = ''

    proc.stderr?.on('data', (chunk: Buffer) => {
      const s = chunk.toString()
      stderr += s

      const durMatch = s.match(/Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})/)
      if (durMatch) {
        const h = Number(durMatch[1])
        const m = Number(durMatch[2])
        const sec = Number(durMatch[3])
        durationSec = h * 3600 + m * 60 + sec
      }

      const timeMatch = s.match(/time=(\d{2}):(\d{2}):(\d{2}\.\d{2})/)
      if (timeMatch && durationSec > 0 && onProgress) {
        const h = Number(timeMatch[1])
        const m = Number(timeMatch[2])
        const sec = Number(timeMatch[3])
        const cur = h * 3600 + m * 60 + sec
        onProgress(Math.min(0.99, cur / durationSec))
      }
    })

    proc.on('error', reject)
    proc.on('close', (code) => {
      if (code === 0) {
        onProgress?.(1)
        resolve({ outputPath })
      } else {
        reject(new Error(`ffmpeg 退出码 ${code}\n${stderr.slice(-2000)}`))
      }
    })
  })
}

export function buildOutputPathFor(
  inputPath: string,
  outputDir: string,
  format: AudioOutputFormat
): string {
  return buildOutputPath(inputPath, outputDir, format)
}

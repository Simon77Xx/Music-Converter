import { mkdir } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'

/** 跨平台：用户主目录下的固定输出子目录 */
export const OUTPUT_DIR_NAME = 'SoftcreateOutput'

export function getOutputDir(): string {
  return join(homedir(), OUTPUT_DIR_NAME)
}

export async function ensureOutputDir(): Promise<string> {
  const dir = getOutputDir()
  await mkdir(dir, { recursive: true })
  return dir
}

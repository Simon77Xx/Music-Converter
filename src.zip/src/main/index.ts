import { app, BrowserWindow, ipcMain, shell } from 'electron'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { randomUUID } from 'node:crypto'
import { ensureOutputDir, getOutputDir } from './paths'
import { analyzePaths } from './analyze'
import { runFfmpeg } from './ffmpeg'
import type { AudioOutputFormat, DropTask } from '../shared/types'
import { zipFolderTo } from './zipFolder'

const __dirname = dirname(fileURLToPath(import.meta.url))

const isDev = process.env.NODE_ENV === 'development' || !!process.env['ELECTRON_RENDERER_URL']

const taskStore = new Map<string, DropTask>()

let petWindow: BrowserWindow | null = null
let processWindow: BrowserWindow | null = null

function getPreloadPath(): string {
  return join(__dirname, '../preload/index.mjs')
}

function createPetWindow(): void {
  petWindow = new BrowserWindow({
    width: 420,
    height: 520,
    frame: false,
    transparent: true,
    hasShadow: false,
    alwaysOnTop: true,
    skipTaskbar: false,
    resizable: false,
    webPreferences: {
      preload: getPreloadPath(),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  })

  if (isDev && process.env['ELECTRON_RENDERER_URL']) {
    petWindow.loadURL(`${process.env['ELECTRON_RENDERER_URL']}/pet.html`)
  } else {
    petWindow.loadFile(join(__dirname, '../renderer/pet.html'))
  }

  petWindow.on('closed', () => {
    petWindow = null
  })
}

function createProcessWindow(taskId: string): void {
  if (processWindow && !processWindow.isDestroyed()) {
    processWindow.close()
  }

  processWindow = new BrowserWindow({
    width: 520,
    height: 640,
    minWidth: 480,
    minHeight: 520,
    show: false,
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: getPreloadPath(),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  })

  const q = `taskId=${encodeURIComponent(taskId)}`

  if (isDev && process.env['ELECTRON_RENDERER_URL']) {
    processWindow.loadURL(`${process.env['ELECTRON_RENDERER_URL']}/process.html?${q}`)
  } else {
    processWindow.loadFile(join(__dirname, '../renderer/process.html'), {
      query: { taskId }
    })
  }

  processWindow.once('ready-to-show', () => processWindow?.show())

  processWindow.on('closed', () => {
    processWindow = null
  })
}

function registerIpc(): void {
  ipcMain.handle('drop:analyze', async (_, paths: string[]) => {
    return analyzePaths(paths)
  })

  ipcMain.handle('task:open', async (_, task: DropTask) => {
    const id = randomUUID()
    taskStore.set(id, task)
    createProcessWindow(id)
    return id
  })

  ipcMain.handle('task:get', async (_, taskId: string) => {
    return taskStore.get(taskId) ?? null
  })

  ipcMain.handle('paths:output-dir', async () => getOutputDir())

  ipcMain.handle('shell:open-path', async (_, p: string) => {
    await shell.openPath(p)
  })

  ipcMain.handle('shell:show-item', async (_, p: string) => {
    shell.showItemInFolder(p)
  })

  ipcMain.handle('job:zip-folder', async (_, payload: { folderPath: string }) => {
    await ensureOutputDir()
    const outDir = getOutputDir()
    const result = await zipFolderTo(payload.folderPath, outDir, (r) => {
      processWindow?.webContents.send('job:progress', r)
    })
    return result
  })

  ipcMain.handle(
    'job:transcode',
    async (
      _,
      payload: {
        paths: string[]
        outputFormat: AudioOutputFormat
        mode: 'convert' | 'compress'
        bitrateKbps?: number
        /** 压缩子模式：有损 → MP3；无损 → FLAC（与 outputFormat 在 compress 模式下由服务端决定） */
        compressProfile?: 'lossy' | 'lossless'
        /** 无损压缩时 FLAC 等级 0–12，默认 8 */
        flacCompressionLevel?: number
      }
    ) => {
      await ensureOutputDir()
      const outDir = getOutputDir()
      const outputs: string[] = []
      const total = payload.paths.length

      const resolveCompress = (): {
        format: AudioOutputFormat
        bitrate?: number
        flacLevel?: number
      } => {
        if (payload.mode !== 'compress') {
          return { format: payload.outputFormat, bitrate: payload.bitrateKbps }
        }
        if (payload.compressProfile === 'lossless') {
          return {
            format: 'flac',
            flacLevel: payload.flacCompressionLevel ?? 8
          }
        }
        return {
          format: 'mp3',
          bitrate: payload.bitrateKbps ?? 128
        }
      }

      const resolved = resolveCompress()

      for (let i = 0; i < payload.paths.length; i++) {
        const inputPath = payload.paths[i]
        const baseProgress = i / total
        const { outputPath } = await runFfmpeg(
          {
            inputPath,
            outputDir: outDir,
            outputFormat: resolved.format,
            audioBitrateKbps: resolved.bitrate,
            flacCompressionLevel: resolved.flacLevel
          },
          (ratio) => {
            const p = baseProgress + (ratio / total) * 0.999
            processWindow?.webContents.send('job:progress', p)
          }
        )
        outputs.push(outputPath)
      }

      processWindow?.webContents.send('job:progress', 1)
      return { outputPaths: outputs, outputDir: outDir }
    }
  )

  ipcMain.handle('window:close-process', async () => {
    if (processWindow && !processWindow.isDestroyed()) {
      processWindow.close()
    }
  })

  ipcMain.handle('pet:set-ignore-mouse', async (_, ignore: boolean) => {
    if (!petWindow || petWindow.isDestroyed()) return
    if (ignore) {
      petWindow.setIgnoreMouseEvents(true, { forward: true })
    } else {
      petWindow.setIgnoreMouseEvents(false)
    }
  })
}

app.whenReady().then(async () => {
  await ensureOutputDir()
  registerIpc()
  createPetWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createPetWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

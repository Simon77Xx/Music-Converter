import archiver from 'archiver'
import { createWriteStream } from 'node:fs'
import { basename, join } from 'node:path'
import { finished } from 'node:stream/promises'

export async function zipFolderTo(
  folderPath: string,
  outputDir: string,
  onProgress?: (ratio: number) => void
): Promise<{ outputPath: string }> {
  const name = basename(folderPath)
  const outputPath = join(outputDir, `${name}.zip`)
  const out = createWriteStream(outputPath)
  const archive = archiver('zip', { zlib: { level: 9 } })

  archive.on('progress', (p) => {
    const total = p.entries.total || 0
    const done = p.entries.processed || 0
    if (total > 0 && onProgress) {
      onProgress(Math.min(0.99, done / total))
    }
  })

  archive.directory(folderPath, false)
  archive.pipe(out)
  onProgress?.(0.05)

  const finalize = archive.finalize()
  await Promise.all([finalize, finished(out)])
  onProgress?.(1)
  return { outputPath }
}

import { contextBridge, ipcRenderer, webUtils } from 'electron'
import type { AudioOutputFormat, DropTask } from '../shared/types'

contextBridge.exposeInMainWorld('softcreate', {
  getPathForFile: (file: File) => webUtils.getPathForFile(file),

  analyzeDrop: (paths: string[]) =>
    ipcRenderer.invoke('drop:analyze', paths) as Promise<DropTask>,

  openTask: (task: DropTask) => ipcRenderer.invoke('task:open', task) as Promise<string>,

  getTask: (taskId: string) =>
    ipcRenderer.invoke('task:get', taskId) as Promise<DropTask | null>,

  getOutputDir: () => ipcRenderer.invoke('paths:output-dir') as Promise<string>,

  zipFolder: (folderPath: string) =>
    ipcRenderer.invoke('job:zip-folder', { folderPath }) as Promise<{ outputPath: string }>,

  transcode: (payload: {
    paths: string[]
    outputFormat: AudioOutputFormat
    mode: 'convert' | 'compress'
    bitrateKbps?: number
    compressProfile?: 'lossy' | 'lossless'
    flacCompressionLevel?: number
  }) =>
    ipcRenderer.invoke('job:transcode', payload) as Promise<{
      outputPaths: string[]
      outputDir: string
    }>,

  onJobProgress: (cb: (ratio: number) => void) => {
    const listener = (_: unknown, ratio: number) => cb(ratio)
    ipcRenderer.on('job:progress', listener)
    return () => ipcRenderer.removeListener('job:progress', listener)
  },

  openPath: (p: string) => ipcRenderer.invoke('shell:open-path', p) as Promise<void>,
  showItemInFolder: (p: string) => ipcRenderer.invoke('shell:show-item', p) as Promise<void>,

  closeProcessWindow: () => ipcRenderer.invoke('window:close-process') as Promise<void>,

  setPetIgnoreMouse: (ignore: boolean) =>
    ipcRenderer.invoke('pet:set-ignore-mouse', ignore) as Promise<void>
})
